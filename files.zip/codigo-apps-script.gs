// COLE ESTE CÓDIGO NO APPS SCRIPT DA SUA PLANILHA GOOGLE SHEETS
// Extensões > Apps Script > apagar o conteúdo padrão > colar isto > Salvar

function doGet(e) {
  var action = e.parameter.action;
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var clientesSheet = ss.getSheetByName('Clientes');
  var comentariosSheet = ss.getSheetByName('Comentarios');

  if (action === 'add_cliente') {
    var id = Utilities.getUuid();
    clientesSheet.appendRow([id, e.parameter.cliente, e.parameter.distribuidora, e.parameter.status, new Date().toISOString()]);
  } else if (action === 'update_status') {
    updateCellByRowId(clientesSheet, e.parameter.id, 4, e.parameter.status);
  } else if (action === 'delete_cliente') {
    deleteRowById(clientesSheet, e.parameter.id);
    deleteCommentsByClienteId(comentariosSheet, e.parameter.id);
  } else if (action === 'add_comment') {
    var commentId = Utilities.getUuid();
    comentariosSheet.appendRow([commentId, e.parameter.clienteId, e.parameter.texto, new Date().toISOString()]);
  }

  var clientes = sheetToObjects(clientesSheet);
  var comentarios = sheetToObjects(comentariosSheet);

  return jsonResponse({ clientes: clientes, comentarios: comentarios });
}

function sheetToObjects(sheet) {
  var data = sheet.getDataRange().getValues();
  var headers = data[0];
  var rows = data.slice(1);
  return rows
    .filter(function (r) { return r[0] !== ''; })
    .map(function (row) {
      var obj = {};
      headers.forEach(function (h, i) { obj[h] = row[i]; });
      return obj;
    });
}

function findRowIndexById(sheet, id) {
  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] === id) return i + 1;
  }
  return -1;
}

function updateCellByRowId(sheet, id, colIndex, value) {
  var rowNum = findRowIndexById(sheet, id);
  if (rowNum > 0) sheet.getRange(rowNum, colIndex).setValue(value);
}

function deleteRowById(sheet, id) {
  var rowNum = findRowIndexById(sheet, id);
  if (rowNum > 0) sheet.deleteRow(rowNum);
}

function deleteCommentsByClienteId(sheet, clienteId) {
  var data = sheet.getDataRange().getValues();
  for (var i = data.length - 1; i >= 1; i--) {
    if (data[i][1] === clienteId) sheet.deleteRow(i + 1);
  }
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
